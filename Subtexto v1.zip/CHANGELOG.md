# Histórico de versões

## 1.0.0-interna — 2026-07-17

Versão congelada para uso profissional nas transmissões.

- Editor de lower thirds com os três templates BNDES.
- Lista inicial com três entradas de Aloizio Mercadante, uma por template.
- Indicação destacada de participante no ar.
- Atualização de nomes pelo mesmo overlay do OBS.
- Integração com OBS WebSocket.
- Exportação de PNG e WebM.
- Fallback de Chroma Key para gravações sem transparência.
- Testes reais realizados em dois computadores com OBS.

Esta versão deve ser preservada. Novos recursos devem ser desenvolvidos em uma cópia separada para a versão pública.
