# Subtexto - Gerador de Lower Third

Ferramenta leve para criação e exibição de lower thirds em transmissões.

**Versão atual: 1.0.0-interna** — congelada para uso profissional em 17/07/2026.

## Estrutura

- `index.html`: editor e painel de controle.
- `overlay.html`: fonte de navegador transparente para o OBS.
- `js/overlay.js`: renderizador leve usado pelo overlay.
- `assets/`: logo e ícones necessários em tempo de execução.

## Uso com OBS

1. Hospede esta pasta em um endereço acessível pelo computador que executa o OBS.
2. Abra o editor pelo `index.html`.
3. No OBS, adicione uma Fonte de Navegador apontando para `overlay.html` usando a URL copiada pelo editor.
4. Mantenha o editor aberto para enviar os comandos de exibição e atualização.

O funcionamento depende de internet para acessar o GitHub Pages e de uma conexão local com o OBS WebSocket.

Os testes operacionais de OBS foram realizados em dois computadores. Antes de uma atualização, repetir o fluxo de mostrar, atualizar e ocultar em cada máquina.

## Arquivos necessários

A pasta `assets` deve permanecer junto do projeto, pois o editor e o overlay carregam os arquivos diretamente dela.

## Política desta versão

Esta é a versão interna com identidade e templates BNDES. Não altere os arquivos diretamente depois da publicação. A versão pública deverá ser criada em uma cópia separada, sem os templates e assets institucionais.
